<style>
  @import url('https://fonts.googleapis.com/css?family=Roboto:400,500,700');

  * {
      -webkit-box-sizing: border-box;
      box-sizing: border-box;
      margin: 0;
      padding: 0;
  }

  .product-main {
      font-family: 'Roboto', sans-serif;
      display: flex;
      justify-content: center;
      align-items: flex-start;
      flex-wrap: wrap;
      background-color: #f8f8f8;
      padding: 20px;
  }

  .product-card {
      width: 300px; /* Reduced width */
      height: 400px; /* Reduced height */
      position: relative;
      box-shadow: 0 2px 7px #dfdfdf;
      margin: 20px;
      background: #fafafa;
      display: flex;
      flex-direction: column;
  }

  .badge {
      position: absolute;
      left: 0;
      top: 10px;
      text-transform: uppercase;
      font-size: 12px;
      font-weight: 700;
      background: red;
      color: #fff;
      padding: 3px 8px;
  }

  .product-tumb {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 200px; /* Adjusted height */
      background: #f0f0f0;
      padding: 20px;
  }

  .product-tumb img {
      max-width: 100%;
      max-height: 100%;
  }

  .product-details {
      padding: 20px; /* Adjusted padding */
      flex-grow: 1; /* Ensures it takes up available space */
  }

  .product-catagory {
      display: block;
      font-size: 11px; /* Reduced font size */
      font-weight: 700;
      text-transform: uppercase;
      color: #ccc;
      margin-bottom: 10px;
  }

  .product-details h4 a {
      font-weight: 500;
      display: block;
      margin-bottom: 10px; /* Adjusted margin */
      text-transform: uppercase;
      color: #363636;
      text-decoration: none;
      transition: 0.3s;
  }

  .product-details h4 a:hover {
      color: #fbb72c;
  }

  .product-details p {
      font-size: 13px; /* Reduced font size */
      line-height: 18px; /* Adjusted line height */
      margin-bottom: 10px;
      color: #999;
  }

  .product-bottom-details {
      overflow: hidden;
      border-top: 1px solid #eee;
      padding-top: 10px;
      display: flex;
      justify-content: space-between;
  }

  .product-price {
      font-size: 16px; /* Reduced font size */
      color: #fbb72c;
      font-weight: 600;
  }

  .product-price small {
      font-size: 80%;
      font-weight: 400;
      text-decoration: line-through;
      display: inline-block;
      margin-right: 5px;
  }

  .product-links a {
      margin-left: 5px;
      color: #e1e1e1;
      transition: 0.3s;
      font-size: 17px;
  }

  .product-links a:hover {
      color:rgb(99, 44, 251);
  }
  .product-details p {
    font-size: 13px; /* Reduced font size */
    line-height: 18px; /* Adjusted line height */
    margin-bottom: 10px;
    color: #999;
    max-height: 54px; /* Limits the height to fit approximately 3 lines */
    overflow: hidden; /* Hides overflowing text */
    text-overflow: ellipsis; /* Adds ellipsis for overflow text */
    display: -webkit-box;
    -webkit-line-clamp: 3; /* Limits to 3 lines */
    -webkit-box-orient: vertical;
}
</style>

  <!-- Hero Carousel -->
  <section id="hero-carousel" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active" data-interval="10000">
      <img src="<?php echo IMAGES_FOLDER . "heroSection-1.jpg" ?>" class="d-block w-100" alt="Car Rental Image 1">
    </div>
    <div class="carousel-item" data-interval="2000">
      <img src="<?php echo IMAGES_FOLDER . "heroSection-2.webp" ?>" class="d-block w-100" alt="Car Rental Image 2">
    </div>
    <div class="carousel-item">
      <img src="<?php echo IMAGES_FOLDER . "heroSection-3.webp" ?>" class="d-block w-100" alt="Car Rental Image 3">
    </div>
  </div>
  <a class="carousel-control-prev" href="#hero-carousel" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#hero-carousel" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</section>


<div class="product-main">
<?php 
if (!empty($productDetails)) {
    
foreach ($productDetails as $product) {
  // echo "<pre>";
  // print_r($product);
  // die;
        ?>
        <div class="product-card">
            <div class="badge"><?= $product->e_availability === 'available' ? 'Available' : 'Unavailable'; ?></div>
            <div class="product-tumb">
                <img src="<?php echo !empty($product->v_image_path) ? $product->v_image_path : 'https://via.placeholder.com/150'; ?>" alt="<?= $product->v_name; ?>">
            </div>
            <div class="product-details">
                <span class="product-catagory"><?= htmlspecialchars($product->v_vehicle_type) . ', ' . htmlspecialchars($product->v_brand); ?></span>
                <h4><a href="<?php echo SITE_URL."products/".$product->i_id ?>"><?= htmlspecialchars($product->v_name); ?></a></h4>
                <p><?= htmlspecialchars($product->v_description); ?></p>
                
                <div class="product-bottom-details">
                    <div class="product-price">
                        <small>₹<?= number_format($product->v_rental_price - 1000, 2); ?></small>
                        ₹<?= number_format($product->v_rental_price, 2); ?>
                    </div>
                    <div class="product-links">
                        <a href="#"><i class="fa fa-heart"></i></a>
                        <a href="#"><i class="fa fa-shopping-cart"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}

?>

</div>