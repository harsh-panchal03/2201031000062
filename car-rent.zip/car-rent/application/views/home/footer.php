<style>

footer {
    background-color: #0d47a1;
    color: #ffffff;
    padding: 2rem 0;
}

.footer-content {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-bottom: 2rem;
}

.footer-logo-img {
    height: 60px;
    margin-bottom: 1rem;
}

.footer-logo p {
    font-size: 1rem;
}

.footer-links,
.footer-social,
.footer-newsletter {
    flex: 1;
    margin: 0 1rem;
}

.footer-links h6,
.footer-social h6,
.footer-newsletter h6 {
    font-size: 1.2rem;
    margin-bottom: 1rem;
    font-weight: 600;
}

.footer-links ul {
    list-style: none;
    padding: 0;
}

.footer-links ul li {
    margin-bottom: 0.5rem;
}

.footer-links ul li a {
    color: #bbdefb;
    text-decoration: none;
    font-size: 1rem;
}

.footer-links ul li a:hover {
    color: #ffffff;
}

.social-icons {
    display: flex;
    gap: 1rem;
}

.icon-link {
    font-size: 1.5rem;
    color: #bbdefb;
    transition: color 0.3s ease;
}

.icon-link:hover {
    color: #ffffff;
}

.footer-newsletter form {
    display: flex;
    flex-direction: column;
}

.footer-newsletter input {
    padding: 0.5rem;
    margin-bottom: 0.5rem;
    border: none;
    border-radius: 5px;
}

.footer-newsletter button {
    padding: 0.5rem;
    background-color: #1976d2;
    color: #ffffff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.footer-newsletter button:hover {
    background-color: #ffffff;
    color: #0d47a1;
}

.footer-bottom {
    text-align: center;
    border-top: 1px solid #ffffff;
    padding-top: 1rem;
}

.footer-bottom p {
    font-size: 0.9rem;
}

</style>



</main>
<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="logo.png" alt="Car Rent Logo" class="footer-logo-img">
                <p>Providing the best cars at unbeatable prices.</p>
            </div>
            <div class="footer-links">
                <h6>QUICK LINKS</h6>
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="book.html">Book Now</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="terms.html">Terms & Conditions</a></li>
                    <li><a href="privacy.html">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="footer-social">
                <h6>CONNECT WITH US</h6>
                <div class="social-icons">
                    <a href="https://instagram.com" aria-label="Instagram" class="icon-link"><i class="fa fa-instagram"></i></a>
                    <a href="https://facebook.com" aria-label="Facebook" class="icon-link"><i class="fa fa-facebook"></i></a>
                    <a href="https://twitter.com" aria-label="Twitter" class="icon-link"><i class="fa fa-twitter"></i></a>
                </div>
                <p><i class="fa fa-envelope"></i> riderent060@gmail.com</p>
                <p><i class="fa fa-phone"></i> +1 (799) 107-9624</p>
            </div>
            <div class="footer-newsletter">
                <h6>SUBSCRIBE TO OUR NEWSLETTER</h6>
                <form action="#" method="post">
                    <input type="email" name="email" placeholder="Enter your email" required>
                    <button type="submit">Subscribe</button>
                </form>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Car Rent. All Rights Reserved.</p>
        </div>
    </div>
</footer>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html>
