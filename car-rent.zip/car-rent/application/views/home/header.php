<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500&family=Roboto:wght@400;700&display=swap" rel="stylesheet">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="style1.css">

  <title>Car Rent</title>

  <style>
   
  @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap');

:root {
  --primary-blue: #0d47a1;
  --secondary-blue: #1976d2;
  --light-blue: #bbdefb;
  --white: #ffffff;
  --light-gray: #f5f5f5;
  --text-dark: #333333;
}

body {
  font-family: 'Montserrat', sans-serif;
  background-color: var(--white);
  color: var(--text-dark);
  line-height: 1.6;
}

#hero-carousel {
    max-height: 600px; /* Adjust this value to your desired height */
    overflow: hidden;
  }

  #hero-carousel .carousel-inner {
    height: 100%;
  }

  #hero-carousel .carousel-item {
    height: 100%;
  }

  #hero-carousel .carousel-item img {
    object-fit: cover;
    object-position: center;
    height: 100%;
    width: 100%;
  }

  @media (max-width: 768px) {
    #hero-carousel {
      max-height: 300px; /* Adjust for smaller screens */
    }
  }


/* Navbar Styles */
.navbar {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;


  background: linear-gradient(90deg, var(--primary-blue), var(--secondary-blue));
  padding: 1rem 0;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.navbar-brand img {
  height: 60px;
  transition: transform 0.3s ease;
}

.navbar-brand img:hover {
  transform: scale(1.05);
}

.nav-link {
  color: var(--white) !important;
  font-weight: 500;
  font-size: 1rem;
  margin: 0 15px;
  transition: all 0.3s ease;
}

.nav-link:hover {
  color: var(--light-blue) !important;
  transform: translateY(-2px);
}
</style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-md">
    <div class="container">
      <a href="#" class="navbar-brand">
        <img src="logo.png" alt="Car Rent Logo">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a href="index.html" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="book.html" class="nav-link">Book Now</a>
          </li>
          <li class="nav-item">
            <a href="index.html#why-us" class="nav-link">Why Us</a>
          </li>
          <li class="nav-item">
            <a href="<?php echo SITE_URL."signup" ?>" class="nav-link">Sign Up</a>
          </li>
          <li class="nav-item">
            <a href="feedback.html" class="nav-link">Feedback</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


  <main>
