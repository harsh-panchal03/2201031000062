<style>

    </style>



<section id="why-us" class="container py-5">
    <h2 class="text-center mb-4 section-title">Why Us?</h2>
    <p class="text-center mb-5 section-description">
        We simplified bike rentals, so you can focus on what's important to you.
    </p>

    <div class="why-us-card-container row">
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="why-us-card text-center p-4">
                <div class="why-us-card-image mb-3">
                    <img src="cardimages/card-bike-1.png" alt="Safe Rides" class="img-fluid">
                </div>
                <h5 class="why-us-card-title">Safe Rides</h5>
                <p class="why-us-card-text">
                    Your safety is our priority. From sanitizing all bikes before every use to extensive on-ground safety measures, your rides with Ride & Rent will always be safe and reliable. We also offer helmets on demand.
                </p>
            </div>
        </div>
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="why-us-card text-center p-4">
                <div class="why-us-card-image mb-3">
                    <img src="cardimages/card-money-2.png" alt="Flexible Ownership" class="img-fluid">
                </div>
                <h5 class="why-us-card-title">Flexible Ownership</h5>
                <p class="why-us-card-text">
                    Enjoy the freedom of owning a two-wheeler without the hefty down-payments, EMIs, and paperwork. Choose from rent-to-own, monthly/quarterly bookings, or even daily plans.
                </p>
            </div>
        </div>
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="why-us-card text-center p-4">
                <div class="why-us-card-image mb-3">
                    <img src="cardimages/card-smartphone-3.png" alt="Smarter Mobility" class="img-fluid">
                </div>
                <h5 class="why-us-card-title">Smarter Mobility</h5>
                <p class="why-us-card-text">
                    Experience smarter transportation with our innovative solutions tailored to your needs.
                </p>
            </div>
        </div>
        <div class="col-md-6 col-lg-3 mb-4">
            <div class="why-us-card text-center p-4">
                <div class="why-us-card-image mb-3">
                    <img src="cardimages/card-parking-4.png" alt="Convenient Stations" class="img-fluid">
                </div>
                <h5 class="why-us-card-title">Convenient Stations</h5>
                <p class="why-us-card-text">
                    Access ride-and-rent stations near you for a seamless rental experience.
                </p>
            </div>
        </div>
    </div>
</section>
