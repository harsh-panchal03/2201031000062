
<div class="breadcrumb-wrapper d-lg-flex p-3 border-bottom">
    <h1 class="h3 mb-lg-0 mr-3" id="pageTitle"><?php echo $this->lang->line("products") ?>( <span id="total-record-count" ></span> )</h1>
    <div class="ml-auto text-right">
        <a href="<?php echo PRODUCT_URL . "showAddForm"?>" class="btn btn-light text-dark border btn-sm mr-2" title="<?php echo $this->lang->line('add-product')?>"><i class="fas fa-plus"></i><?php echo $this->lang->line('add-product')?></a>
        <button class="btn btn-light border btn-sm" data-toggle="collapse" data-target="#searchFilter" title="Toggle Filter"><i class="fas fa-filter"></i><?php echo $this->lang->line('filter')?></button>
    </div>
</div>
<div class="container-fluid pt-3">
<?php echo $this->session->flashdata("myMessage")?>
<div class="collapse" id="searchFilter">
    <div class="card card-body border-0 shadow mb-4">
        <div class="row">
            <!-- Name Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_name"><?php echo $this->lang->line('name') ?></label>
                    <input type="text" class="form-control" id="search_name" name="search_name" onchange="filterData()">
                </div>
            </div>

            <!-- Vehicle Type Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_vehicle_type"><?php echo $this->lang->line('vehicle-type') ?></label>
                    <select class="form-control select2" id="search_vehicle_type" name="search_vehicle_type" onchange="filterData()">
                        <option value=""><?php echo $this->lang->line("select") ?></option>
                        <option value="car">Car</option>
                        <option value="bike">Bike</option>
                    </select>
                </div>
            </div>

            <!-- Brand Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_brand"><?php echo $this->lang->line('brand') ?></label>
                    <input type="text" class="form-control" id="search_brand" name="search_brand" onchange="filterData()">
                </div>
            </div>

            <!-- Model Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_model"><?php echo $this->lang->line('model') ?></label>
                    <input type="text" class="form-control" id="search_model" name="search_model" onchange="filterData()">
                </div>
            </div>

            <!-- Year Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_year"><?php echo $this->lang->line('year') ?></label>
                    <input type="number" class="form-control" id="search_year" name="search_year" onchange="filterData()">
                </div>
            </div>

            <!-- Mileage Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_mileage"><?php echo $this->lang->line('mileage') ?></label>
                    <input type="number" class="form-control" id="search_mileage" name="search_mileage" onchange="filterData()">
                </div>
            </div>

            <!-- Fuel Type Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_fuel_type"><?php echo $this->lang->line('fuel-type') ?></label>
                    <select class="form-control select2" id="search_fuel_type" name="search_fuel_type" onchange="filterData()">
                        <option value=""><?php echo $this->lang->line("select") ?></option>
                        <option value="petrol">Petrol</option>
                        <option value="diesel">Diesel</option>
                        <option value="electric">Electric</option>
                        <option value="hybrid">Hybrid</option>
                    </select>
                </div>
            </div>

            <!-- Transmission Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_transmission"><?php echo $this->lang->line('transmission') ?></label>
                    <select class="form-control select2" id="search_transmission" name="search_transmission" onchange="filterData()">
                        <option value=""><?php echo $this->lang->line("select") ?></option>
                        <option value="manual">Manual</option>
                        <option value="automatic">Automatic</option>
                    </select>
                </div>
            </div>

            <!-- Seating Capacity Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_seating_capacity"><?php echo $this->lang->line('seating-capacity') ?></label>
                    <input type="number" class="form-control" id="search_seating_capacity" name="search_seating_capacity" onchange="filterData()">
                </div>
            </div>

            <!-- Rental Price Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_rental_price"><?php echo $this->lang->line('rental-price') ?></label>
                    <input type="number" class="form-control" id="search_rental_price" name="search_rental_price" onchange="filterData()">
                </div>
            </div>

            <!-- Availability Filter -->
            <div class="col-lg-3 col-md-6">
                <div class="form-group">
                    <label class="control-label" for="search_availability"><?php echo $this->lang->line('availability') ?></label>
                    <select class="form-control select2" id="search_availability" name="search_availability" onchange="filterData()">
                        <option value=""><?php echo $this->lang->line("select") ?></option>
                        <option value="available">Available</option>
                        <option value="unavailable">Unavailable</option>
                    </select>
                </div>
            </div>

            <!-- Search and Reset Buttons -->
            <div class="col-md pt-lg-2 mt-md-4 mt-lg-0">
                <button type="button" onclick="filterData()" class="btn btn-info mt-lg-3"><?php echo $this->lang->line('search') ?></button>
                <button type="button" onclick="resetFilter()" class="btn btn-outline-secondary reset-wild-tigers mt-lg-3"><?php echo $this->lang->line('reset') ?></button>
            </div>
        </div>
    </div>
</div>

    <div class="filter-result-wrapper">
        <h3 class="h4 mb-3"><?php echo $this->lang->line("all-products")?></h3>
        <div class="card card-body shadow-sm">
            <div class="table-responsive">
                <table class="table table-sm table-bordered table-hover">
                <thead>
                        <tr>
                            <th class="sr-col"><?php echo $this->lang->line("sr-no") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("name") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("vehicle-type") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("brand") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("model") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("year") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("mileage") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("fuel-type") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("transmission") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("seating-capacity") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("rental-price") ?></th>
                            <th class="text-center"><?php echo $this->lang->line("availability") ?></th>
                            <th class="actions-col"><?php echo $this->lang->line("actions") ?></th>
                        </tr>
                    </thead>
                    <tbody class="ajax-view">
                    <?php echo $this->load->view( AJAX_FOLDER."product/product-list" , [] , true); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<script>


var product_url = "<?php echo PRODUCT_URL ?>";
var paginationUrl = product_url +  "filter";

function searchFiled(){
    
    var searchData = {};
    searchData.search_status = $.trim($("[name='search_status']").val());
searchData.search_brand = $.trim($("[name='search_brand']").val());
searchData.search_category = $.trim($("[name='search_category']").val());
searchData.search_name = $.trim($("[name='name']").val());
searchData.search_vehicle_type = $.trim($("[name='search_vehicle_type']").val());
searchData.search_model = $.trim($("[name='search_model']").val());
searchData.search_year = $.trim($("[name='search_year']").val());
searchData.search_mileage = $.trim($("[name='search_mileage']").val());
searchData.search_fuel_type = $.trim($("[name='search_fuel_type']").val());
searchData.search_transmission = $.trim($("[name='search_transmission']").val());
searchData.search_seating_capacity = $.trim($("[name='search_seating_capacity']").val());
searchData.search_rental_price = $.trim($("[name='search_rental_price']").val());
searchData.search_availability = $.trim($("[name='search_availability']").val());

return searchData;


    
}


function filterData(){


	var searchFieldName = searchFiled();
	
	
	searchAjax(product_url + 'filter', searchFieldName);
	


}



</script>
<?php echo $this->load->view( ADMIN_FOLDER."srcoll-based-pagination" , [] , true ) ?>
