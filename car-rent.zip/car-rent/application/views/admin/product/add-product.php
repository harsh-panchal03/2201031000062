<div class="breadcrumb-wrapper d-lg-flex p-3 border-bottom">
    <h1 class="h3 mb-lg-0 mr-3" id="pageTitle"><?php echo $pageTitle ?></h1>
    <nav aria-label="breadcrumb" class="d-flex mr-3">
        <ol class="breadcrumb bg-transparent p-0 mb-0 align-self-end">
            <li class="breadcrumb-item"><a href="<?php echo PRODUCT_URL ?>"><?php echo $this->lang->line("all-vehicles") ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $pageTitle ?></li>
        </ol>
    </nav>
</div>
<div class="container-fluid pt-3">
    <div class="card card-body mb-3 shadow-sm">
      		<?php echo form_open_multipart(PRODUCT_URL."add" , [ "id" => "addVehicleForm" , "method" => "post" ]) ?>
            <div class="row">
            <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="name"><?php echo $this->lang->line('name')?><span class="text-danger">*</span>:</label>
                        <input type="text" class="form-control" id="name" name="name"  value="<?php echo   ( ( isset($recordInfo->v_name) && !empty($recordInfo->v_name) ) ? $recordInfo->v_name : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="vehicle_type"><?php echo $this->lang->line('vehicle-type')?><span class="text-danger">*</span>:</label>
                        <select class="form-control select2" id="vehicle_type" name="vehicle_type" required>
                            <option value=""><?php echo $this->lang->line("select") ?></option>
                            <option value="car" <?php echo (isset($recordInfo->v_vehicle_type) && $recordInfo->v_vehicle_type === 'car') ? 'selected' : ''; ?>>Car</option>
                            <option value="bike" <?php echo (isset($recordInfo->v_vehicle_type) && $recordInfo->v_vehicle_type === 'bike') ? 'selected' : ''; ?>>Bike</option>
                        </select>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="brand"><?php echo $this->lang->line('brand')?><span class="text-danger">*</span>:</label>
                        <input type="text" class="form-control" id="brand" name="brand" value="<?php echo   ( ( isset($recordInfo->v_brand) && !empty($recordInfo->v_brand) ) ? $recordInfo->v_brand : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="model"><?php echo $this->lang->line('model')?><span class="text-danger">*</span>:</label>
                        <input type="text" class="form-control" id="model" name="model" value="<?php echo   ( ( isset($recordInfo->v_model) && !empty($recordInfo->v_model) ) ? $recordInfo->v_model : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="year"><?php echo $this->lang->line('year')?><span class="text-danger">*</span>:</label>
                        <input type="number" class="form-control" id="year" name="year" value="<?php echo   ( ( isset($recordInfo->v_year) && !empty($recordInfo->v_year) ) ? $recordInfo->v_year : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="mileage"><?php echo $this->lang->line('mileage')?><span class="text-danger">*</span>:</label>
                        <input type="number" class="form-control" id="mileage" name="mileage" value="<?php echo   ( ( isset($recordInfo->v_mileage) && !empty($recordInfo->v_mileage) ) ? $recordInfo->v_mileage : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="fuel_type"><?php echo $this->lang->line('fuel-type')?><span class="text-danger">*</span>:</label>
                        <select class="form-control select2" id="fuel_type" name="fuel_type" required>
                            <option value=""><?php echo $this->lang->line("select")?></option>
                            <option value="petrol" <?php echo (isset($recordInfo) && !empty($recordInfo->v_fuel_type) && $recordInfo->v_fuel_type == 'petrol') ? 'selected' : '' ?>>Petrol</option>
                            <option value="diesel" <?php echo (isset($recordInfo) && !empty($recordInfo->v_fuel_type) && $recordInfo->v_fuel_type == 'diesel') ? 'selected' : '' ?>>Diesel</option>
                            <option value="electric" <?php echo (isset($recordInfo) && !empty($recordInfo->v_fuel_type) && $recordInfo->v_fuel_type == 'electric') ? 'selected' : '' ?>>Electric</option>
                            <option value="hybrid" <?php echo (isset($recordInfo) && !empty($recordInfo->v_fuel_type) && $recordInfo->v_fuel_type == 'hybrid') ? 'selected' : '' ?>>Hybrid</option>
                        </select>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="transmission"><?php echo $this->lang->line('transmission')?><span class="text-danger">*</span>:</label>
                        <select class="form-control select2" id="transmission" name="transmission" required>
                            <option value=""><?php echo $this->lang->line("select")?></option>
                            <option value="manual" <?php echo (isset($recordInfo) && !empty($recordInfo->v_transmission) && $recordInfo->v_transmission == 'manual') ? 'selected' : '' ?>>Manual</option>
                            <option value="automatic" <?php echo (isset($recordInfo) && !empty($recordInfo->v_transmission) && $recordInfo->v_transmission == 'automatic') ? 'selected' : '' ?>>Automatic</option>
                        </select>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="seating_capacity"><?php echo $this->lang->line('seating-capacity')?><span class="text-danger">*</span>:</label>
                        <input type="number" class="form-control" id="seating_capacity" name="seating_capacity" value="<?php echo   ( ( isset($recordInfo->v_seating_capacity) && !empty($recordInfo->v_seating_capacity) ) ? $recordInfo->v_seating_capacity : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="rental_price"><?php echo $this->lang->line('rental-price')?><span class="text-danger">*</span>:</label>
                        <input type="number" class="form-control" id="rental_price" name="rental_price" value="<?php echo   ( ( isset($recordInfo->v_rental_price) && !empty($recordInfo->v_rental_price) ) ? $recordInfo->v_rental_price : '' ); ?>" required>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="availability"><?php echo $this->lang->line('availability')?><span class="text-danger">*</span>:</label>
                        <select class="form-control select2" id="availability" name="availability" required>
                            <option value=""><?php echo $this->lang->line("select")?></option>
                            <option value="available" <?php echo (isset($recordInfo) && !empty($recordInfo->e_availability) && $recordInfo->e_availability == 'available') ? 'selected' : '' ?>>Available</option>
                            <option value="unavailable" <?php echo (isset($recordInfo) && !empty($recordInfo->e_availability) && $recordInfo->e_availability == 'unavailable') ? 'selected' : '' ?>>Unavailable</option>
                        </select>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="description"><?php echo $this->lang->line('description')?>:</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?php echo (isset($recordInfo) && !empty($recordInfo->v_description)) ? $recordInfo->v_description : '' ?></textarea>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <label class="control-label" for="vehicle_image"><?php echo $this->lang->line('vehicle-image')?><span class="text-danger">*</span>:</label>
                        <input type="file" class="form-control-file" id="vehicle_image" name="vehicle_image" required>
                    </div>
                </div>


            <input type="hidden" name="record_id" value="<?php echo ( ( isset($recordInfo) && !empty($recordInfo->i_id) ) ?  $this->anand_electrical->encode( $recordInfo->i_id ) : "" )?>" />    
                <div class="col-md-12">
                    <button type="submit" class="btn bg-success text-white btn-wide"><?php echo $this->lang->line('submit')?></button>
                    <a href="<?php echo PRODUCT_URL ?>" class="btn btn-outline-secondary btn-wide"><?php echo $this->lang->line("cancel")?></a>
                </div>
            </div>
            
        <?php echo form_close() ?>
    </div>
</div>
<script>
    $("#addVehicleForm").validate({
        errorClass: "invalid-input",
        rules: {
            vehicle_type: {
                required: true,
            },
            brand: {
                required: true
            },
            model: {
                required: true
            },
            year: {
                required: true,
                number: true
            },
            mileage: {
                required: true,
                number: true
            },
            fuel_type: {
                required: true
            },
            transmission: {
                required: true
            },
            seating_capacity: {
                required: true,
                number: true
            },
            rental_price: {
                required: true,
                number: true
            },
            availability: {
                required: true
            },
            vehicle_image: {
                required: true
            }
        },
        messages: {
            vehicle_type: {
                required: "<?php echo sprintf($this->lang->line('common-select-filed-validation'), $this->lang->line('vehicle-type'))?>",
            },
            brand: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('brand'))?>",
            },
            model: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('model'))?>",
            },
            year: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('year'))?>",
                number: "<?php echo sprintf($this->lang->line('common-field-number-validation'), $this->lang->line('year'))?>"
            },
            mileage: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('mileage'))?>",
                number: "<?php echo sprintf($this->lang->line('common-field-number-validation'), $this->lang->line('mileage'))?>"
            },
            fuel_type: {
                required: "<?php echo sprintf($this->lang->line('common-select-filed-validation'), $this->lang->line('fuel-type'))?>",
            },
            transmission: {
                required: "<?php echo sprintf($this->lang->line('common-select-filed-validation'), $this->lang->line('transmission'))?>",
            },
            seating_capacity: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('seating-capacity'))?>",
                number: "<?php echo sprintf($this->lang->line('common-field-number-validation'), $this->lang->line('seating-capacity'))?>"
            },
            rental_price: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('rental-price'))?>",
                number: "<?php echo sprintf($this->lang->line('common-field-number-validation'), $this->lang->line('rental-price'))?>"
            },
            availability: {
                required: "<?php echo sprintf($this->lang->line('common-select-filed-validation'), $this->lang->line('availability'))?>",
            },
            vehicle_image: {
                required: "<?php echo sprintf($this->lang->line('common-field-required-validation'), $this->lang->line('vehicle-image'))?>",
            }
        },
        submitHandler: function(form) {
            showLoader()
            form.submit();
        }
    });
</script>

</div>

</div>