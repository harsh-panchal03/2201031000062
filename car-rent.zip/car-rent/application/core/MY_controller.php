<?php 
require("application/controllers/Guest.php");

class MY_controller extends Guest{
    public function __construct(){
        parent::__construct();
        
        if($this->session->has_userdata("userId") != true && empty($this->session->userdata("userId"))){
            redirect(LOGIN_URL);
        }
    }

    
    public function loadAdminView( $headerData = [], $pageName = "" , $pageData = [], $footerData = []){
             
       $this->load->view(ADMIN_FOLDER.'layouts/header' , $headerData);
       $this->load->view($pageName , $pageData);
       $this->load->view(ADMIN_FOLDER.'layouts/footer' , $footerData);

    }
    
    public function ajaxResponse( $statusCode , $message , $data = null ){
        
        $response = [];
        $response['status_code'] = $statusCode;
        $response['message'] = $message;
        
        if(!empty($data)){
            $response['data'] = $data;
        }
        
        echo json_encode($response);die;
        
    }
    
    public function masterStatusUpdate( $tableName ,$moduleName){
       
        if(getPostData('record_id')){
            
            $statusCode = ERROR_AJAX_CALL;
            $recordId = (int)$this->anand_electrical->decode( getPostData('record_id') );
            $status = getPostData('status');
            $result = false;
            
            if(!empty($status)){
                switch ($status){
                    case ACTIVE_STATUS_TEXT :
                       $doStatus = ACTIVE_STATUS;
                       $changeStatus = $this->lang->line("active");
                       break;
                    case INACTIVE_STATUS_TEXT :
                       $doStatus = INACTIVE_STATUS;
                       $changeStatus = $this->lang->line("inactive");
                       break;
                    default:
                       break;
                } 
                $result = $this->my_model->updateTableData( $tableName , [ 't_is_active' => $doStatus ] , [ 'i_id'  => $recordId] );
            }
           
            if($result != false){
                $message =  sprintf($this->lang->line('success-update-status') ,$moduleName , $changeStatus ); 
                $statusCode = SUCCESS_AJAX_CALL;
            }else{
                $message = sprintf($this->lang->line("error-update-status"),$changeStatus , $moduleName );
                $statusCode = ERROR_AJAX_CALL;
            }
            $this->ajaxResponse($statusCode,$message );
        }
        $this->ajaxResponse(ERROR_AJAX_CALLr, $this->lang->line("system-error"));
    }
    
    public function removeRecord( $tableName , $recordId , $moduleName){
        
        if(!empty($tableName)){
            
            $recordId = (int)$this->anand_electrical->decode($recordId);
            
            $result = $this->my_model->deleteTableData( $tableName , [] , [ "i_id" => $recordId ] );
            if($result != false){
                $message = sprintf($this->lang->line("success-delete"), $moduleName);
                $this->anand_electrical->setFlashMessage( "success" , $message );
            }else{
                $message = sprintf($this->lang->line("error-delete"), $moduleName);
                $this->anand_electrical->setFlashMessage("danger" , $message);            }
            
        }
        
        redirect($this->redirectUrl);
        
    }
    
    public function uploadImage($fieldName, $uploadPath, $allowedTypes = 'jpg|jpeg|png|gif', $maxSize = 2048)
{
    // Prepend FCPATH to ensure the full path
    $fullUploadPath = FCPATH ."uploads/". $uploadPath;

    // Check if the upload path exists, if not, create it
    if (!is_dir($fullUploadPath)) {
        mkdir($fullUploadPath, 0777, true); // Create the directory with proper permissions
    }

    $config = [
        'upload_path'   => $fullUploadPath, // Full directory path to save the uploaded image
        'allowed_types' => $allowedTypes, // Allowed file types
        'max_size'      => $maxSize, // Max file size in KB
        'file_name'     => uniqid() . '_' . $_FILES[$fieldName]['name'], // Unique file name
    ];

    $this->load->library('upload', $config);

    if (!$this->upload->do_upload($fieldName)) {
        // Return error message if upload fails
        return ['status' => false, 'error' => $this->upload->display_errors()];
    }

    // Get the file data after successful upload
    $fileData = $this->upload->data();
    $path = UPLOAD_FOLDER.$uploadPath.$fileData['file_name'];
    // Return only the relative image path
    return ['status' => true, 'path' => $path];
}

    
    
}