<?php


class Product_model extends My_model{
    
    public function __construct(){
        parent::__construct();
        $this->singleRecord = false;
        
    }
    
    public function getRecordDetails($selectData = [], $whereData = [], $likeData = [], $additionalData = [])
{
    $tableName = PRODUCT_TABLE . " as p";
    
    if (empty($selectData)) {
        $selectData = [
           'p.i_id',
            'p.v_name',
            'p.v_vehicle_type',
            'p.v_brand',
            'p.v_model',
            'p.v_year',
            'p.v_mileage',
            'p.v_fuel_type',
            'p.v_transmission',
            'p.v_seating_capacity',
            'p.v_rental_price',
            'p.e_availability',
            'p.v_description',
            'p.v_image_path',
            // 'p.v_license_plate',
            // 'p.v_color',
            // 'p.v_insurance_expiry',
            'p.t_is_active',
         ];
    }
    
    if (isset($whereData['singleRecord']) && $whereData['singleRecord'] != false) {
        $this->singleRecord = true;
        unset($whereData['singleRecord']);
    }
    
    $defaultWhere = [
        'p.t_is_deleted' => 0 // Assuming you have an is_deleted column
    ];
    
    $whereData = array_merge($defaultWhere, $whereData);
    
    $data = [];
    
    if ($this->singleRecord) {
        $data = $this->getSingleRecordById($tableName, $selectData, $whereData);
    } else {
        $data = $this->selectData($tableName, $selectData, $whereData, $likeData, $additionalData);
    }
    
    // Process the data to format certain fields
    // if (!empty($data)) {
    //     $data = is_array($data) ? $data : [$data];
    //     foreach ($data as &$record) {
    //         $record->rental_price = number_format($record->rental_price, 2);
    //         $record->insurance_expiry = date('Y-m-d', strtotime($record->insurance_expiry));
    //         $record->availability = ucfirst($record->availability);
    //         $record->created_at = date('Y-m-d H:i:s', strtotime($record->created_at));
    //         $record->updated_at = date('Y-m-d H:i:s', strtotime($record->updated_at));
    //     }
    //     if ($this->singleRecord) {
    //         $data = $data[0];
    //     }
    // }
    
    return $data;
}

}