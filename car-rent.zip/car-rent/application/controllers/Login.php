<?php

class Login extends Guest {
    public function __construct() {
        parent::__construct();
        
        if($this->session->has_userdata("userId") != false && !empty($this->session->userdata("userId"))){
            redirect(DASHBOARD_URL);
        }
        
        
        $this->load->model("login_model" , "crud_model");
    }


    public function index(){
        
        

    $this->load->view('login/login');
    }

    public function showAddForm(){
        echo "hi0;";
    }

    // public function checkAdminLogin(){
        
        
        
    //     if(!empty($this->input->post())){
            
    //         $this->form_validation->set_rules('login_email' , $this->lang->line('email') , 'trim|required|xss_clean');
    //         $this->form_validation->set_rules('login_password' , $this->lang->line('password') , 'trim|required|xss_clean');

    //         if($this->form_validation->run() != true){
    //             print_r(validation_errors());
    //         } else{
                
    //             $message = $this->lang->line("email-not-exist");
               
                
    //             $email = (!empty($this->input->post("login_email")) ? $this->input->post("login_email") : "");
    //             $password = (!empty($this->input->post("login_password")) ? $this->input->post("login_password") : "");

                
    //             if(!empty($email)){
    //                 $checkLogin = $this->crud_model->getRecordDetails ( [] , [ "v_email" => $email ]);
                    
    //                 if(!empty($checkLogin)){

    //                     if( isset($checkLogin->t_is_active) && $checkLogin->t_is_active != ACTIVE_STATUS){
    //                         $message = $this->lang->line("inactive-account");
    //                     }
                        
    //                     $verifyPassword = password_verify( $password , $checkLogin->v_password );
                        
    //                     if($verifyPassword != false){
    //                         $this->commonSessionEntry($checkLogin);
    //                         redirect(DASHBOARD_URL);
    //                     }
    //                 }
    //              }
                 
    //              $this->anand_electrical->setFlashMessage( "danger" , $message );
    //         }
    //     }
    //     redirect(LOGIN_URL);
    // }

    public function checkAdminLogin(){
        // echo "<pre>";
        // print_r($this->input->post());
        // die;
        if (!empty($this->input->post())) {
            // Determine if we are logging in or signing up
            $loginType = $this->input->post('login_type'); // 'login' for login, 'signup' for signup
            if ($loginType === 'login') {
                // Set validation rules for login
                $this->form_validation->set_rules('login_email', $this->lang->line('email'), 'trim|required|xss_clean');
                $this->form_validation->set_rules('login_password', $this->lang->line('password'), 'trim|required|xss_clean');
        
                if ($this->form_validation->run() != true) {
                    print_r(validation_errors());
                } else {
                    $message = $this->lang->line("email-not-exist");
                    $email = $this->input->post("login_email");
                    $password = $this->input->post("login_password");
        
                    if (!empty($email)) {
                        // Check if the email exists in the database
                        $checkLogin = $this->crud_model->getRecordDetails([], ["v_email" => $email]);
        
                        if (!empty($checkLogin)) {
                            // Check if the account is active
                            if (isset($checkLogin->t_is_active) && $checkLogin->t_is_active != ACTIVE_STATUS) {
                                $message = $this->lang->line("inactive-account");
                            } else {
                                // Verify password
                                if (password_verify($password, $checkLogin->v_password)) {
                                    // Successful login
                                    $this->commonSessionEntry($checkLogin);
                                    redirect(DASHBOARD_URL);
                                } else {
                                    $message = $this->lang->line("invalid-password");
                                }
                            }
                        }
                    }
        
                    // Set flash message for login failure
                    $this->anand_electrical->setFlashMessage("danger", $message);
                }
            } else if ($loginType === 'signup') {
               
                // Set validation rules for signup
                // $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
                // $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean');
                // $this->form_validation->set_rules('signup_email_or_phone', 'Email or Phone', 'trim|required|valid_email|xss_clean');
               // $this->form_validation->set_rules('login_password', 'Password', 'trim|required|min_length[6]|xss_clean');
        
                //if ($this->form_validation->run() != true) {
                    print_r(validation_errors());
               // } else {
                    // Prepare data for new user registration
                    $firstName = $this->input->post("name");
                  //  $lastName = $this->input->post("last_name");
                    $email = $this->input->post("login_email");
                    $signupPassword = password_hash($this->input->post("login_password") ,PASSWORD_DEFAULT); // Hash the password
        
                    // Check if email already exists
                    $existingUser = $this->crud_model->getRecordDetails(['i_id'], ["v_email" => $email]);
                    
                    //if (!empty($existingUser)) {
                        // Email already exists
                       // echo "callYEs";
                        $message = "Email or phone number already registered.";
                       // $this->anand_electrical->setFlashMessage("danger", $message);
                   // } else {
                        // Register new user
                        $data = [
                            'v_name' => $firstName,
                            'e_role' => 'user',
                            'v_email' => $email,
                            'v_password' => $signupPassword,
                            't_is_active' => ACTIVE_STATUS, // Assuming new users are active by default
                        ];
                        
                        // Insert user into the database
                     //   $data =$this->crud_model->insertTableData('login_master', $data);

                        
                        if ($this->crud_model->insertTableData('login_master', $data)) { // Replace 'users_table' with your actual table name
                            // Successful signup
                           // die("asdasdasd");
                           $checkLogin = $this->crud_model->getRecordDetails([], ["v_email" => $email]);
                    
                           $this->commonSessionEntry($checkLogin);
                            redirect(LOGIN_URL); // Redirect to login page after successful signup
                        } else {
                            // Handle insertion error
                            $message = "There was an error creating your account. Please try again.";
                            $this->anand_electrical->setFlashMessage("danger", $message);
                        }
                   // }
              //  }
            }
            echo $loginType;
            die;
           
            redirect(LOGIN_URL); // Redirect to login page after processing
        }
        
    }
}