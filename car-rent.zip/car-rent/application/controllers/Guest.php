<?php

class Guest extends CI_Controller{
    
    public $tableName;
    public $folderName ;
    public $redirectUrl;
    public $perPageRecord;
    
    
    public function __construct(){
        parent::__construct();
        $this->tableName = "";
        $this->folderName ="";
        $this->redirectUrl = "";
        $this->perPageRecord = PER_PAGE;
        $this->load->model('my_model' , 'my_model');
        
    }

    public function guestObject(){
        echo "guest function called"; die;
    }
    
    

    public function home(){

        $headerData = $data = [] ;
        $headerData['name'] = "panchal harsh";

        $data['productDetails'] = $this->my_model->selectData ( PRODUCT_TABLE , [ '*'] , ["t_is_deleted !=" => ACTIVE_STATUS ]);
        
         
        $this->load->view('home/header' , $headerData);
        $this->load->view('home/home', $data );
        $this->load->view('home/footer' );
    }

    public function signup(){
        
        // $this->load->view('home/header');
        $this->load->view('home/signup');
        // $this->load->view('home/footer' );
         

    }

    public function productDetail($id){
        $this->load->view('home/header');
        $this->load->view('home/product-detail');
        $this->load->view('home/footer' );
         
    }

    public function checkLogin(){
        
    }


    public function commonSessionEntry($checkLogin){
       
        if(!empty($checkLogin)){
           
            $userData = [];
            $userData['userName'] = (!empty($checkLogin->v_name) ? $checkLogin->v_name : "");
            $userData['role'] = (!empty($checkLogin->v_role) ? $checkLogin->v_name :"");
            $userData['userId'] = (!empty($checkLogin->i_id) ? $checkLogin->i_id : "");
            $userData['userEmail'] = (!empty($checkLogin->v_email) ? $checkLogin->v_email : "");
            
            $this->session->set_userdata($userData);
            
        }
    }

    
}