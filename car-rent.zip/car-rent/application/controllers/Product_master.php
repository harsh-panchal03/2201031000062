<?php


class Product_master extends  MY_controller{
    
    
    public function __construct(){
       
        parent::__construct();
        
        $this->tableName = PRODUCT_TABLE;
        $this->redirectUrl = PRODUCT_URL;
        $this->folderName = ADMIN_FOLDER."product/";
        $this->perPageRecord = PER_PAGE;
        $this->moduleName = $this->lang->line("product");
        $this->load->model('product_model' , 'crud_model');
        
    }
    
    public function index(){
        
        
        
        $headerData = $data = [];
        $paginationData = $whereData = [];
        
        $page = (!empty($this->input->post("page")) ? $this->input->post("page") : DEFAULT_PAGE_INDEX );
        
        if($page == DEFAULT_PAGE_INDEX){
            
            $totalRecord = count($this->crud_model->getRecordDetails( [ 'i_id' ] ));
            $paginationData['current_page'] = DEFAULT_PAGE_INDEX;
            $paginationData['per_page_record'] = $this->perPageRecord;
            $lastPage = ceil($totalRecord/$this->perPageRecord);
            $paginationData['last_page'] = $lastPage;
            
            
        }
        //uhlzvhu
        
        
        $whereData['limit'] = $this->perPageRecord;
        $whereData['offset'] = 0;
        
        $recordDetails  = $this->crud_model->getRecordDetails([] , $whereData);
        $data['recordDetails'] = $recordDetails;
        $data['pagination'] = $paginationData;
        $headerData['pageTitle'] = $this->lang->line('product');
        $data['pageTitle'] = $headerData['pageTitle'];
        
        $data['pageNo'] = $page;
        $data['totalRecord'] = $totalRecord;
        
        
        $this->loadAdminView($headerData , $this->folderName . "product" , $data);
        
    }
    
    public function filter(){
        if(!empty($this->input->post())){
    
            $headerData = $paginationData = $whereData = $data = [];
            $page = (!empty($this->input->post('page')) ? $this->input->post('page') : DEFAULT_PAGE_INDEX);
           
            
            if (!empty($this->input->post('search_city'))) {
                $whereData['i_id'] = $this->anand_electrical->decode($this->input->post("search_city"));
            }
            
            if (!empty($this->input->post('search_status'))) {
                $whereData['t_is_active'] = ($this->input->post('search_status') == ACTIVE_STATUS_TEXT ? ACTIVE_STATUS : INACTIVE_STATUS);
            }
            
            if (!empty($this->input->post('search_brand'))) {
                $whereData['brand'] = $this->input->post('search_brand');
            }
            
            if (!empty($this->input->post('search_category'))) {
                $whereData['category'] = $this->input->post('search_category');
            }
            
            if (!empty($this->input->post('search_name'))) {
                $whereData['v_name'] = $this->input->post('search_name');
            }
            
            if (!empty($this->input->post('search_vehicle_type'))) {
                $whereData['v_vehicle_type'] = $this->input->post('search_vehicle_type');
            }
            
            if (!empty($this->input->post('search_model'))) {
                $whereData['v_model'] = $this->input->post('search_model');
            }
            
            if (!empty($this->input->post('search_year'))) {
                $whereData['v_year'] = $this->input->post('search_year');
            }
            
            if (!empty($this->input->post('search_mileage'))) {
                $whereData['v_mileage'] = $this->input->post('search_mileage');
            }
            
            if (!empty($this->input->post('search_fuel_type'))) {
                $whereData['v_fuel_type'] = $this->input->post('search_fuel_type');
            }
            
            if (!empty($this->input->post('search_transmission'))) {
                $whereData['v_transmission'] = $this->input->post('search_transmission');
            }
            
            if (!empty($this->input->post('search_seating_capacity'))) {
                $whereData['v_seating_capacity'] = $this->input->post('search_seating_capacity');
            }
            
            if (!empty($this->input->post('search_rental_price'))) {
                $whereData['v_rental_price'] = $this->input->post('search_rental_price');
            }
            
            if (!empty($this->input->post('search_availability'))) {
                $whereData['e_availability'] = $this->input->post('search_availability');
            }
            
            
            
            if(!empty($this->input->post('search_status'))){
                $whereData['t_is_active'] = ($this->input->post('search_status') == ACTIVE_STATUS_TEXT ? ACTIVE_STATUS : INACTIVE_STATUS );
            }
           
            if($page == DEFAULT_PAGE_INDEX){
                
                $totalRecord = count($this->crud_model->getRecordDetails( [ 'i_id' ]  , $whereData ));
                $paginationData['current_page'] = DEFAULT_PAGE_INDEX;
                $paginationData['per_page_record'] = $this->perPageRecord;
                $lastPage = ceil($totalRecord/$this->perPageRecord);
                $paginationData['last_page'] = $lastPage;
            }
            
            
            if($page == DEFAULT_PAGE_INDEX){
                $whereData['limit'] = $this->perPageRecord;
                $whereData['offset'] = 0;
                $data['totalRecord'] = $totalRecord;
            }else{
                $whereData['limit'] = $this->perPageRecord;
                $whereData['offset'] = ( $page - 1 )* $this->perPageRecord;
            }
           
            
            $recordDetails  = $this->crud_model->getRecordDetails([] , $whereData);
            
            $data['recordDetails'] = $recordDetails;
            $data['pagination'] = $paginationData;
            $headerData['pageTitle'] = $this->lang->line('sub-stations');
            $data['pageTitle'] = $headerData['pageTitle'];
            
            $data['pageNo'] = $page;
            
            $html = $this->load->view( AJAX_FOLDER. "product/product-list", $data , true);
            echo $html;die;
        
            
        }
    }
    
    public function showAddForm(){
        
        
        $headerData = $data = [];
        
        $headerData['pageTitle'] = $this->lang->line("add-city");
        $data['pageTitle'] = $headerData['pageTitle'];
        // $data['stateDetails'] = getStateDetails();

        $this->loadAdminView($headerData, $this->folderName . "add-product" , $data);
    }
    
    public function add()
{
    $this->form_validation->set_rules("vehicle_type", "Vehicle Type", "required|trim");
    $this->form_validation->set_rules("brand", "Brand", "required|trim");
    $this->form_validation->set_rules("model", "Model", "required|trim");
    $this->form_validation->set_rules("year", "Year", "required|numeric");
    $this->form_validation->set_rules("mileage", "Mileage", "required|numeric");
    $this->form_validation->set_rules("fuel_type", "Fuel Type", "required|trim");
    $this->form_validation->set_rules("transmission", "Transmission", "required|trim");
    $this->form_validation->set_rules("seating_capacity", "Seating Capacity", "required|numeric");
    $this->form_validation->set_rules("rental_price", "Rental Price", "required|numeric");
    $this->form_validation->set_rules("availability", "Availability", "required|trim");
    $this->form_validation->set_rules("description", "Description", "required|trim");

    if ($this->form_validation->run() != TRUE) {
        die("this call");
        $this->showAddForm();
    } else {
        
        // Call the reusable image upload function
        $uploadResult = $this->uploadImage('vehicle_image', "product/");
        
        if (!$uploadResult['status']) {
            // Show upload error message and return to form
            
            $this->session->set_flashdata("error", $uploadResult['error']);
            $this->showAddForm();
            return;
        }

        // Get uploaded file path
        $imagePath = $uploadResult['path'];

        // Prepare record data
        $recordData = [
            'v_name'              => $this->input->post('name'),
            'v_vehicle_type'     => $this->input->post('vehicle_type'),
            'v_brand'            => $this->input->post('brand'),
            'v_model'            => $this->input->post('model'),
            'v_year'             => $this->input->post('year'),
            'v_mileage'          => $this->input->post('mileage'),
            'v_fuel_type'        => $this->input->post('fuel_type'),
            'v_transmission'     => $this->input->post('transmission'),
            'v_seating_capacity' => $this->input->post('seating_capacity'),
            'v_rental_price'     => $this->input->post('rental_price'),
            'e_availability'     => $this->input->post('availability'),
            'v_description'      => $this->input->post('description'),
            'v_image_path'       => $imagePath,
        ];

        // Insert into database
        $insertId = $this->crud_model->insertTableData($this->tableName, $recordData);

        if ($insertId > 0) {
            $this->anand_electrical->setFlashMessage( "success" , $this->lang->line('vehicle_added_successfully'));
           // $this->session->set_flashdata("success", );
        } else {
            $this->session->set_flashdata("error", $this->lang->line('failed_to_add_vehicle'));
        }

        redirect($this->redirectUrl);
    }
}


    
    public function showEditForm( $recordId = null ){
        $errorFound = true;
        
        if(!empty($recordId)){
            $recordId = (int)$this->anand_electrical->decode($recordId);
            
            $recordInfo = $this->crud_model->getRecordDetails( [] , [ "i_id" => $recordId , "singleRecord" =>  TRUE ] );
            
            if(!empty($recordInfo)){
                
                $errorFound = false;
                
                $headerData = $data = [];
                $headerData['pageTitle'] = $this->lang->line("update-city");
                $data['recordInfo'] = $recordInfo;
                $this->loadAdminView($headerData, $this->folderName . "add-product" , $data);
                
            }
        }
        
        if($errorFound != false){
            dd("page not Found");
        }
    }
    
    public function delete( $recordId = null ){
        $errorFound = true;
        
        if(!empty($recordId)){
            $this->removeRecord($this->tableName , $recordId , $this->moduleName);
        }
        
    }
    
    public function statusUpdate(){
        if(!empty($this->input->post())){
            $this->masterStatusUpdate($this->tableName, $this->moduleName);
        }
    }
    
    
}